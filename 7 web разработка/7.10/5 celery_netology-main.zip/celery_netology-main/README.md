## Это учебный проект Нетологии

### Запуск Postgres
```docker-compose up postgre```

### Запуск Redis
```docker-compose up redis```

### Запуск Mongo
```docker-compose up mongo```

### Запуск API
```docker-compose up app```

### Запуск Celery 
```docker-compose up celery```
